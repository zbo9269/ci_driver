#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define FIBER_IOC_MAGIC  'm'
#define FIBER_IOC_RESET    _IO(FIBER_IOC_MAGIC, 0)
#define FIBER_IOC_ALLOC_MEMORY _IOWR(FIBER_IOC_MAGIC,  1, int)
#define FIBER_IOC_MAXNR 1

int main()
{
    printf("FIBER_IOC_RESET:%#x\n",FIBER_IOC_RESET);
    printf("FIBER_IOC_ALLOC_MEMORY:%#x\n",FIBER_IOC_ALLOC_MEMORY);
    return 0;
}
