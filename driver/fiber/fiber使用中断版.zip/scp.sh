#!  /bin/bash

# set -x

function transfer()
{
    echo "transfer to ${1}"
    home=/root/driver/fiber/
    # scp -r /root/ci/src/platform/series_manage.* root@${1}:/root/ci/src/platform/
    # scp -r /root/ci/src/platform/cfg_compare.c root@${1}:/root/ci/src/platform/
    #scp -r ${home}fiber.ko root@${1}:${home}
    #scp -r ${home}/*.py root@${1}:${home}
    scp -r ${home}/* root@${1}:${home}
    ssh root@${1} ${home}/fiber.sh restart
}

#transfer 192.168.1.200
#transfer 192.168.1.201
#transfer 192.168.1.202
#transfer 192.168.1.203
transfer 192.168.1.205
transfer 192.168.1.206
transfer 192.168.1.207

