#include <stdio.h>

int main()
{
    int a = 0xffe;
    return 0;
}
