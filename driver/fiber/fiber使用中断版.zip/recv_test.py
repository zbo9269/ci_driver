#!  /usr/bin/python3

import struct
import fcntl
from xxd import xxd_bin
from random import randint
from fcntl import ioctl

def reset_memory(file_name):
    """
    reset memory
    """
    FIBER_IOC_RESET = 0x6d00

    fiber_fp = open(file_name,"wb",0)
    ioctl(fiber_fp.fileno(),FIBER_IOC_RESET)

    fiber_fp.close()

    return

def alloc_memory(file_name,size):
    """
    use ioctl alloc memory for fp
    """
    FIBER_IOC_ALLOC_MEMORY = 0xc0046d01

    fiber_fp = open(file_name,"wb",0)
    ioctl(fiber_fp.fileno(),FIBER_IOC_ALLOC_MEMORY,size)

    fiber_fp.close()

    return

def recv_data(file_name,size):
    """
    this function try recv message
    """
    fiber_fp = open(file_name,"rb",0)

    try:
        #size = 0xff7
        #size = 0xff
        b = fiber_fp.read(size)
        if b:
            print("has read %d num from %s" % (len(b),file_name))
            xxd_bin(b)
        else:
            print("none data read from %s" % file_name)
        print()
    except Exception as e:
        print("read from %s failed %s" % (file_name,e))
    finally:
        fiber_fp.close()
    return

def alloc_add_recv_all():
    a1_size = 16
    a2_size = 20745
    a3_size = 1999
    a4_size = 17
    a5_size = 210

    reset_memory("/dev/fibera1")
    alloc_memory("/dev/fibera1",a1_size)
    alloc_memory("/dev/fibera2",a2_size)
    alloc_memory("/dev/fibera3",a3_size)
    alloc_memory("/dev/fibera4",a4_size)
    alloc_memory("/dev/fibera5",a5_size)
    alloc_memory("/dev/fiberb1",a1_size)
    alloc_memory("/dev/fiberb2",a2_size)
    alloc_memory("/dev/fiberb3",a3_size)
    alloc_memory("/dev/fiberb4",a4_size)
    alloc_memory("/dev/fiberb5",a5_size)

    recv_data("/dev/fibera1",a1_size)
    #recv_data("/dev/fibera2",a2_size)
    #recv_data("/dev/fibera3",a3_size)
    #recv_data("/dev/fibera4",a4_size)
    #recv_data("/dev/fibera5",a5_size)

    #recv_data("/dev/fiberb1",a1_size)
    #recv_data("/dev/fiberb2",a2_size)
    #recv_data("/dev/fiberb3",a3_size)
    #recv_data("/dev/fiberb4",a4_size)
    #recv_data("/dev/fiberb5",a5_size)
    return

def alloc_recv_no_stop_a():
    a1_size = 32
    #a1_size = 1024 * 3
    reset_memory("/dev/fibera1")
    alloc_memory("/dev/fibera1",a1_size)

    while 1:
        recv_data("/dev/fibera1",a1_size)
    return

def alloc_recv_no_stop_b():
    a1_size = 32
    #a1_size = 1024 * 3
    reset_memory("/dev/fiberb1")
    alloc_memory("/dev/fiberb1",a1_size)

    while 1:
        recv_data("/dev/fiberb1",a1_size)
    return

def alloc_recv_no_stop():
    #a1_size = 0xff0 * 10
    a1_size = 32
    reset_memory("/dev/fibera1")
    alloc_memory("/dev/fibera1",a1_size)
    alloc_memory("/dev/fiberb1",a1_size)

    while 1:
        recv_data("/dev/fibera1",a1_size)
        recv_data("/dev/fiberb1",a1_size)
        print("----------------------------------")
    return

if __name__ == "__main__":
    alloc_recv_no_stop()
